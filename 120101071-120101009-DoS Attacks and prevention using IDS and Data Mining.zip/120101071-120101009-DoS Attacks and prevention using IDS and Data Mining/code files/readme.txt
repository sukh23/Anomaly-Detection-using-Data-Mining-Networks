readme - How to run code

first run "preprocessNSL.py" to create data matrices and store in pickle files for further uses.
After running it will create 8 files. Put all files into folder name "NSLkdd"

to run a particular classifier open "runner.py"
1. uncomment the code belonging to particular model
2. if you want to save the classifier, uncomment the line clf.save_classifier("...", "...")
3. to load the classifier, uncomment line clf.load_classifier("...", "...")
note: on first run you cannot load classifier.

To change the parameters of classifier some options can be given in runner itself, else one can change values in "trainData()" function where the classifier is being trained. This function is present in every model, just go to model folder and open class file.

In "predictData" function in every model there is a line "Xt['data'], self.Yt = self.modify_five(Xt['data'],self.Yt)", this line is responsible for checking accuracy on 10% and 1% data on "FIVE" and changing "modify_five" to "modify" does same thing for BINARY. percentage can be defined in these functions.

In evaluation function for "BINARY" data code should be

for i in range(0,self.r):
    if self.Yt[i]==self.Ypre[i]:
        match+=1
    if self.Yt[i]==-1:
        t_a+=1
        if self.Ypre[i]==-1:
            a_a+=1
        else:
            a_n+=1
    if self.Yt[i]==1:
        t_n+=1
        if self.Ypre[i]==1:
            n_n+=1
        else:
            n_a+=1

and for "FIVE" data code should be

for i in range(0,self.r):
    if self.Yt[i]==self.Ypre[i]:
        match+=1
    if self.Yt[i]!=0:
        t_a+=1
        if self.Ypre[i]!=0:
            a_a+=1
        else:
            a_n+=1
    if self.Yt[i]==0:
        t_n+=1
        if self.Ypre[i]==0:
            n_n+=1
        else:
            n_a+=1
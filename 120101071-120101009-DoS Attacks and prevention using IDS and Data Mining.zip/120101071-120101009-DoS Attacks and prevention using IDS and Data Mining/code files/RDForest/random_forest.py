# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 20:15:43 2016

@author: Sukhpal
"""

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import normalize
from sklearn.externals import joblib
import pickle
import matplotlib.pyplot as plt
import numpy as np

class RDForest():
    file_names = [['TrainX_binary_full.pkl', 'TrainY_binary_full.pkl', 'TestX_binary_full.pkl', 'TestY_binary_full.pkl'],
                  ['TrainX_whole_full.pkl', 'TrainY_whole_full.pkl', 'TestX_whole_full.pkl', 'TestY_whole_full.pkl'],
    ['TrainX_five_full.pkl', 'TrainY_five_full.pkl', 'TestX_five_full.pkl', 'TestY_five_full.pkl'],
    ['TrainX_whole_partial.pkl', 'TrainY_whole_partial.pkl', 'TestX_whole_partial.pkl', 'TestY_whole_partial.pkl'],
    ['TrainX_binary_partial.pkl', 'TrainY_binary_partial.pkl', 'TestX_binary_partial.pkl', 'TestY_binary_partial.pkl'],
    ['TrainX_five_partial.pkl', 'TrainY_five_partial.pkl', 'TestX_five_partial.pkl', 'TestY_five_partial.pkl']]
    
    folder = ['whole_full', 'binary_full', 'five_full', 'whole_partial', 'binary_partial', 'five_partial',
              'whole_sub', 'binary_sub', 'five_sub', 'binary_full_ir', 'whole_full_ir',
              'five_full_ir', 'whole_partial_ir', 'binary_partial_ir', 'five_partial_ir', 'NSLkdd']
    
    trainfold_indx=0
    testfold_indx=0
    trainfile_indx=0
    testfile_indx=0
    
    def __init__(self,TF,Tf,tF,tf):
        self.trainfold_indx=TF
        self.testfold_indx=tF
        self.trainfile_indx=Tf
        self.testfile_indx=tf
    
    '''
        save the trained classifier into disk
    '''
    def save_classifier(self,fnm, fnm1):
        joblib.dump(self.clf, fnm)
        try:
            joblib.dump(self.fsm, fnm1)
        except:
            print "no feature selection opt"
    
    '''
        load the trained classifier from disk
    '''    
    def load_classifier(self, fnm, fnm1):
        self.clf = joblib.load(fnm)
        try:
            self.fsm = joblib.load(fnm1)
        except:
            print "no feature selection opt"


    '''
        This function train the classifier on the training data
        Parameters: control parameters of algorithm and is data to be normalised
    '''    
    def trainData(self, is_norm=False, para_n_estimators=20, para_n_jobs=3):
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][0],'rb')
        XT = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][1],'rb')
        YT = pickle.load(fr)
        fr.close()
        if is_norm==True:
            XT['data'] = normalize(XT['data'], axis=0)
        
        self.clf = RandomForestClassifier(n_estimators=para_n_estimators, n_jobs=para_n_jobs, criterion='gini',
                                          max_depth=20, min_samples_split=2, min_samples_leaf=40,
                                          min_weight_fraction_leaf=0.0, max_features='auto',
                                          max_leaf_nodes=None, bootstrap=True, oob_score=False,
                                          random_state=None, verbose=0, warm_start=False, class_weight=None)
        self.clf = self.clf.fit(XT['data'], YT['data'])
    
    
    def modify_five(self,X,Y):
        nor=0
        (r,) = Y.shape
        for i in range(0,r):
            if Y[i]==0:
                nor+=1
        ana = 0.01*nor
        ana_c=0
        del_list = []
        for i in range(0,r):
            if Y[i]!=0:
                ana_c+=1
                if ana_c>ana:
                    del_list.append(i)
        X = np.delete(X, del_list, axis=0)
        Y = np.delete(Y, del_list, axis=0)
        return X,Y

    def modify(self,X,Y):
        nor=0
        (r,) = Y.shape
        for i in range(0,r):
            if Y[i]==1:
                nor+=1
        ana = 0.01*nor
        ana_c=0
        del_list = []
        for i in range(0,r):
            if Y[i]==-1:
                ana_c+=1
                if ana_c>ana:
                    del_list.append(i)
        X = np.delete(X, del_list, axis=0)
        Y = np.delete(Y, del_list, axis=0)
        return X,Y
    
    
    
    '''
        This function predict the classes using the classifier on the training data
        Parameters: control parameters of algorithm and is data to be normalised
    '''
    def predictData(self, is_norm=False):
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][2],'rb')
        Xt = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][3],'rb')
        self.Yt = pickle.load(fr)
        fr.close()
        self.Yt = self.Yt['data']
        (self.r, ) = self.Yt.shape
        if is_norm==True:
            Xt['data'] = normalize(Xt['data'], axis=0)
            
        #modify test data
        Xt['data'], self.Yt = self.modify_five(Xt['data'],self.Yt)
        (self.r, ) = self.Yt.shape    
        self.Ypre = self.clf.predict(Xt['data'])
    
    
    
    '''
        This function evaluate the performance of the classifier on the test data,
        in terms of percentage correct prediction.
    '''
    def evaluate(self):
        match = 0
        t_n=0
        t_a=0
        n_n=0
        a_a=0
        n_a=0
        a_n=0
        for i in range(0,self.r):
            if self.Yt[i]==self.Ypre[i]:
                match+=1
            if self.Yt[i]!=0:
                t_a+=1
                if self.Ypre[i]!=0:
                    a_a+=1
                else:
                    a_n+=1
            if self.Yt[i]==0:
                t_n+=1
                if self.Ypre[i]==0:
                    n_n+=1
                else:
                    n_a+=1
        pr = float(a_a)/(a_a + n_a)
        re = float(a_a)/(a_a + a_n)
        print "total requests: " + str(t_n + t_a)
        print "total normal: " + str(t_n) + " correct np: " + str(n_n) + " incorrect np: " + str(n_a)
        print "total abnormal: " + str(t_a) + " correct ap: " + str(a_a) + " incorrect ap: " + str(a_n)
        print "percenrage accuracy: " + str(float(match*100)/self.r)
        print "precision: " + str(pr)
        print "recall: " + str(re)
        print "F1: " + str(float(2*pr*re)/(pr+re))
    


    '''
        This function performs training, prediction and evaluation on training data and testing data,
        on series of varying values of a particular parameter that controls algorithm and plot the graph using
        matplotlib for python
    '''
    def test_range_plot(self,para_min, para_max, incr, is_norm=False):
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][0],'rb')
        XT = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][1],'rb')
        YT = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][2],'rb')
        Xt = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][3],'rb')
        Yt = pickle.load(fr)
        fr.close()
        Yt = Yt['data']
        (r, ) = Yt.shape
        if is_norm==True:
            XT['data'] = normalize(XT['data'], axis=0)
            Xt['data'] = normalize(Xt['data'], axis=0)
        
        k=para_min
        k_val = []
        val = []
        while k<=para_max:
            clf = RandomForestClassifier(n_estimators=k, n_jobs=3, criterion='gini',
                                          max_depth=12, min_samples_split=2, min_samples_leaf=40,
                                          min_weight_fraction_leaf=0.0, max_features='auto',
                                          max_leaf_nodes=None, bootstrap=True, oob_score=False,
                                          random_state=None, verbose=0, warm_start=False, class_weight=None)
            clf = clf.fit(XT['data'], YT['data'])
            Ypre = clf.predict(Xt['data'])
            match = 0
            for i in range(0,r):
                if Yt[i]==Ypre[i]:
                    match+=1
            print str(k) + "   " + str(float(match*100)/r)
            k_val.append(k)
            val.append(float(match*100)/r)
            k+=incr
        plt.plot(k_val, val, 'ro')
        plt.axis([para_min-1, para_max+1, 80, 100])
        plt.show()
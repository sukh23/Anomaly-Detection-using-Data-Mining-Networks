# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 11:06:23 2016

@author: Sukhpal
"""

from sklearn import svm
from sklearn import feature_selection
from sklearn import ensemble
from sklearn.externals import joblib
from sklearn.preprocessing import normalize
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
import pickle
import numpy as np
import matplotlib.pyplot as plt

class SVM():
    file_names = [['TrainX_binary_full.pkl', 'TrainY_binary_full.pkl', 'TestX_binary_full.pkl', 'TestY_binary_full.pkl'],
                  ['TrainX_whole_full.pkl', 'TrainY_whole_full.pkl', 'TestX_whole_full.pkl', 'TestY_whole_full.pkl'],
    ['TrainX_five_full.pkl', 'TrainY_five_full.pkl', 'TestX_five_full.pkl', 'TestY_five_full.pkl'],
    ['TrainX_whole_partial.pkl', 'TrainY_whole_partial.pkl', 'TestX_whole_partial.pkl', 'TestY_whole_partial.pkl'],
    ['TrainX_binary_partial.pkl', 'TrainY_binary_partial.pkl', 'TestX_binary_partial.pkl', 'TestY_binary_partial.pkl'],
    ['TrainX_five_partial.pkl', 'TrainY_five_partial.pkl', 'TestX_five_partial.pkl', 'TestY_five_partial.pkl']]
    
    folder = ['whole_full', 'binary_full', 'five_full', 'whole_partial', 'binary_partial', 'five_partial',
              'whole_sub', 'binary_sub', 'five_sub', 'binary_full_ir', 'whole_full_ir',
              'five_full_ir', 'whole_partial_ir', 'binary_partial_ir', 'five_partial_ir', 'NSLkdd']
    
    trainfold_indx=0
    testfold_indx=0
    trainfile_indx=0
    testfile_indx=0
    
    def __init__(self,TF,Tf,tF,tf):
        self.trainfold_indx=TF
        self.testfold_indx=tF
        self.trainfile_indx=Tf
        self.testfile_indx=tf
    
    '''
        save the trained classifier into disk
    '''
    def save_classifier(self,fnm, fnm1):
        joblib.dump(self.clf, fnm)
        try:
            joblib.dump(self.fsm, fnm1)
        except:
            print "no feature selection opt"
    
    '''
        load the trained classifier from disk
    '''    
    def load_classifier(self, fnm, fnm1):
        self.clf = joblib.load(fnm)
        try:
            self.fsm = joblib.load(fnm1)
        except:
            print "no feature selection opt"


    '''
        based on fs_method parameter, create the feature_selection model, which caan then be used
        parameters can be changed if user wishes.
        'UNI' implements Univariate selection model and different modes can be used
        'SFM' implements Select From Model selection model, different classifier can be used from ensemble pack.
    '''
    def f_selection(self,x,y,fs_method):
        if fs_method=='UNI':
            self.fsm=feature_selection.GenericUnivariateSelect(score_func=feature_selection.chi2,mode='fpr',param=0.05).fit(x, y)
        elif fs_method=='SFM':
            clf1 = ensemble.ExtraTreesClassifier()
            clf1 = clf1.fit(x, y)
            self.fsm = feature_selection.SelectFromModel(clf1, prefit=True, threshold=.0005)
            
   
   

    '''
        This function train the classifier on the training data
        Parameters: control parameters of algorithm and is data to be normalised
    '''    
    def trainData(self, is_feature_selection=False, is_norm=False, para_C=1.0, para_cache_size=250, fs_method='UNI'):
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][0],'rb')
        XT = pickle.load(fr)
        fr.close()
        print "training data size: " + str(XT['data'].shape[0])
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][1],'rb')
        YT = pickle.load(fr)
        fr.close()
        if is_norm==True:
#            XT['data'] = StandardScaler().fit_transform(XT['data'])
            XT['data'] = MinMaxScaler().fit_transform(XT['data'])
#            XT['data'] = normalize(XT['data'], axis=0)
            
        if is_feature_selection==True:
            self.f_selection(XT['data'], YT['data'], fs_method)
            XT['data']=self.fsm.transform(XT['data'])
        
        self.clf = svm.SVC(C=para_C, cache_size=para_cache_size, class_weight=None, coef0=0.0,
    decision_function_shape=None, degree=3, gamma='auto', kernel='rbf',
    max_iter=2733, probability=False, random_state=None, shrinking=True,
    tol=0.0001, verbose=False)
        self.clf = self.clf.fit(XT['data'], YT['data'])
    
    
    def modify_five(self,X,Y):
        nor=0
        (r,) = Y.shape
        for i in range(0,r):
            if Y[i]==0:
                nor+=1
        ana = 0.01*nor
        ana_c=0
        del_list = []
        for i in range(0,r):
            if Y[i]!=0:
                ana_c+=1
                if ana_c>ana:
                    del_list.append(i)
        X = np.delete(X, del_list, axis=0)
        Y = np.delete(Y, del_list, axis=0)
        return X,Y

    def modify(self,X,Y):
        nor=0
        (r,) = Y.shape
        for i in range(0,r):
            if Y[i]==1:
                nor+=1
        ana = 0.01*nor
        ana_c=0
        del_list = []
        for i in range(0,r):
            if Y[i]==-1:
                ana_c+=1
                if ana_c>ana:
                    del_list.append(i)
        X = np.delete(X, del_list, axis=0)
        Y = np.delete(Y, del_list, axis=0)
        return X,Y



    '''
        This function predict the classes using the classifier on the training data
        Parameters: control parameters of algorithm and is data to be normalised
    '''    
    def predictData(self, is_feature_selection=False, is_norm=False):
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][2],'rb')
        Xt = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][3],'rb')
        self.Yt = pickle.load(fr)
        fr.close()
        self.Yt = self.Yt['data']
        (self.r, ) = self.Yt.shape
        if is_norm==True:
#            Xt['data'] = StandardScaler().fit_transform(Xt['data'])
            Xt['data'] = MinMaxScaler().fit_transform(Xt['data'])
#            Xt['data'] = normalize(Xt['data'], axis=0)
            
        if is_feature_selection==True:
            Xt['data']=self.fsm.transform(Xt['data'])
        
        #modify test data
#        Xt['data'], self.Yt = self.modify_five(Xt['data'],self.Yt)
        (self.r, ) = self.Yt.shape
        print Xt['data'].shape
        self.Ypre = self.clf.predict(Xt['data'])
    
    
    
    '''
        This function evaluate the performance of the classifier on the test data,
        in terms of percentage correct prediction.
    '''
    def evaluate(self):
        match = 0
        t_n=0
        t_a=0
        n_n=0
        a_a=0
        n_a=0
        a_n=0
        for i in range(0,self.r):
            if self.Yt[i]==self.Ypre[i]:
                match+=1
            if self.Yt[i]!=0:
                t_a+=1
                if self.Ypre[i]!=0:
                    a_a+=1
                else:
                    a_n+=1
            if self.Yt[i]==0:
                t_n+=1
                if self.Ypre[i]==0:
                    n_n+=1
                else:
                    n_a+=1
        pr = float(a_a)/(a_a + n_a)
        re = float(a_a)/(a_a + a_n)
        print "total requests: " + str(t_n + t_a)
        print "total normal: " + str(t_n) + " correct np: " + str(n_n) + " incorrect np: " + str(n_a)
        print "total abnormal: " + str(t_a) + " correct ap: " + str(a_a) + " incorrect ap: " + str(a_n)
        print "percenrage accuracy: " + str(float(match*100)/self.r)
        print "precision: " + str(pr)
        print "recall: " + str(re)
        print "F1: " + str(float(2*pr*re)/(pr+re))
        
    
    
    '''
        This function performs training, prediction and evaluation on training data and testing data,
        on series of varying values of a particular parameter that controls algorithm and plot the graph using
        matplotlib for python
    '''
    def test_range_plot(self,para_min, para_max, incr, is_norm=False):
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][0],'rb')
        XT = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][1],'rb')
        YT = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][2],'rb')
        Xt = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][3],'rb')
        Yt = pickle.load(fr)
        fr.close()
        Yt = Yt['data']
        (r, ) = Yt.shape
        if is_norm==True:
            XT['data'] = normalize(XT['data'], axis=0)
            Xt['data'] = normalize(Xt['data'], axis=0)
        
        k=para_min
        k_val = []
        val = []
        while k<=para_max:
            clf = svm.SVC(C=k, cache_size=500)
            clf = clf.fit(XT['data'], YT['data'])
            Ypre = clf.predict(Xt['data'])
            match = 0
            for i in range(0,r):
                if Yt[i]==Ypre[i]:
                    match+=1
            print str(k) + "   " + str(float(match*100)/r)
            k_val.append(k)
            val.append(float(match*100)/r)
            k+=incr
        plt.plot(k_val, val, 'ro')
        plt.axis([20, 260, 80, 100])
        plt.show()

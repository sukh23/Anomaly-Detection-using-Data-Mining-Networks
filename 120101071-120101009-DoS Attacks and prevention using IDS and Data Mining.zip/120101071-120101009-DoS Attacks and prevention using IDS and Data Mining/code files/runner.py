# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 18:43:49 2016

@author: Sukhpal
"""


"""
file_names = [['TrainX_binary_full.pkl', 'TrainY_binary_full.pkl', 'TestX_binary_full.pkl', 'TestY_binary_full.pkl'],
    ['TrainX_whole_full.pkl', 'TrainY_whole_full.pkl', 'TestX_whole_full.pkl', 'TestY_whole_full.pkl'],
    ['TrainX_five_full.pkl', 'TrainY_five_full.pkl', 'TestX_five_full.pkl', 'TestY_five_full.pkl'],
    ['TrainX_whole_partial.pkl', 'TrainY_whole_partial.pkl', 'TestX_whole_partial.pkl', 'TestY_whole_partial.pkl'],
    ['TrainX_binary_partial.pkl', 'TrainY_binary_partial.pkl', 'TestX_binary_partial.pkl', 'TestY_binary_partial.pkl'],
    ['TrainX_five_partial.pkl', 'TrainY_five_partial.pkl', 'TestX_five_partial.pkl', 'TestY_five_partial.pkl']]
    
    folder = ['whole_full', 'binary_full', 'five_full', 'whole_partial', 'binary_partial',
    'five_partial', 'whole_sub', 'binary_sub', 'five_sub', 'binary_full_ir', 'whole_full_ir',
              'five_full_ir', 'whole_partial_ir', 'binary_partial_ir', 'five_partial_ir', 'NSLkdd']

"""


from svm import svm
from NBayes import NB as nb
from decision_tree import DecisionTree as dt
from RDForest import random_forest as rd
from kmeans import kmeans
from hybrid import hybrid1 as hy

if __name__=='__main__':
    '''
        Gaussian Naive Bayes
    '''
#    clf = nb.NBayes(15,2,15,2)
#    clf.trainData(False,False,'UNI')
#    clf.save_classifier("NBayes/FIVE/clf.pkl", "NBayes/FIVE/fsm.pkl")
##    clf.load_classifier("NBayes/FIVE/clf.pkl", "NBayes/FIVE/fsm.pkl")
#    clf.predictData(False,False)
#    clf.evaluate()
    
    '''
        K Means
    '''
#    clf = kmeans.k_means(15,2,15,2)
##    clf.trainData(False,False, 60, 14, 600)
##    clf.save_classifier("kmeans/FIVE/clf.pkl", "kmeans/FIVE/centroid.pkl")
#    clf.load_classifier("kmeans/FIVE/clf.pkl", "kmeans/FIVE/centroid.pkl")
#    clf.predictData(False, False)
#    clf.evaluate()
    
    '''
        Hybrid1
    '''
#    clf = hy.hybrid(15,2,15,2)
##    clf.trainData(False,False,  para_n_cluster=34, para_n_init=14, para_max_iter=600, para_n_jobs=2, para_max_depth=12, para_min_samples_leaf=40, para_min_samples_split=2, fs_method='UNI')
##    clf.save_classifier("hybrid/BINARY/clfKM.pkl", "hybrid/BINARY/centroid.pkl", "hybrid/BINARY/clfDT.pkl")
#    clf.load_classifier("hybrid/FIVE/clfKM.pkl", "hybrid/FIVE/centroid.pkl", "hybrid/FIVE/clfDT.pkl")
#    clf.predictData(False, False)
#    clf.evaluate()
    
    '''
        SVM
    '''
    clf = svm.SVM(15,0,15,0)
    clf.trainData(True,True,2500.0,500,'UNI')
#    clf.save_classifier("svm/BINARY/clf.pkl", "svm/BINARY/fsm.pkl")
#    clf.load_classifier("svm/FIVE/clf.pkl", "svm/FIVE/fsm.pkl")
    clf.predictData(True,True)
    clf.evaluate()
    
    '''
        Decision Tree CART
    '''
#    clf = dt.Dtree(15,2,15,2)
#    clf.trainData(False,False,12,40,2)
#    clf.save_classifier("decision_tree/FIVE/clf.pkl", "decision_tree/FIVE/fsm.pkl")
##    clf.load_classifier("decision_tree/FIVE/clf.pkl", "decision_tree/FIVE/fsm.pkl")
#    clf.predictData(False,False)
#    clf.evaluate()
    
    '''
        Random Forest Hybrid
    '''
#    clf = rd.RDForest(15,2,15,2)
#    clf.trainData(False, 20)
#    clf.save_classifier("RDForest/FIVE/clf.pkl", "RDForest/FIVE/fsm.pkl")
##    clf.load_classifier("RDForest/FIVE/clf.pkl", "RDForest/FIVE/fsm.pkl")
#    clf.predictData(False)
#    clf.evaluate()
#    clf.test_range_plot(10,100,10,False)
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 27 00:58:05 2016

@author: Sukhpal
"""


from sklearn.tree import DecisionTreeClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import normalize
from sklearn import feature_selection
from sklearn import ensemble
from sklearn.externals import joblib
import pickle
import numpy as np
import matplotlib.pyplot as plt

class hybrid():
    file_names = [['TrainX_binary_full.pkl', 'TrainY_binary_full.pkl', 'TestX_binary_full.pkl', 'TestY_binary_full.pkl'],
                  ['TrainX_whole_full.pkl', 'TrainY_whole_full.pkl', 'TestX_whole_full.pkl', 'TestY_whole_full.pkl'],
    ['TrainX_five_full.pkl', 'TrainY_five_full.pkl', 'TestX_five_full.pkl', 'TestY_five_full.pkl'],
    ['TrainX_whole_partial.pkl', 'TrainY_whole_partial.pkl', 'TestX_whole_partial.pkl', 'TestY_whole_partial.pkl'],
    ['TrainX_binary_partial.pkl', 'TrainY_binary_partial.pkl', 'TestX_binary_partial.pkl', 'TestY_binary_partial.pkl'],
    ['TrainX_five_partial.pkl', 'TrainY_five_partial.pkl', 'TestX_five_partial.pkl', 'TestY_five_partial.pkl']]
    
    folder = ['whole_full', 'binary_full', 'five_full', 'whole_partial', 'binary_partial',
              'five_partial', 'whole_sub', 'binary_sub', 'five_sub', 'binary_full_ir', 'whole_full_ir',
              'five_full_ir', 'whole_partial_ir', 'binary_partial_ir', 'five_partial_ir', 'NSLkdd']
    
    trainfold_indx=0
    testfold_indx=0
    trainfile_indx=0
    testfile_indx=0
    
    def __init__(self,TF,Tf,tF,tf):
        self.trainfold_indx=TF
        self.testfold_indx=tF
        self.trainfile_indx=Tf
        self.testfile_indx=tf
    
    '''
        save the trained classifier and clusters information into disk
    '''  
    def save_classifier(self,fnm, fnm1,fnm2):
        joblib.dump(self.clfKM, fnm)
        joblib.dump(self.centroid, fnm1)
        joblib.dump(self.clfDT, fnm2)
     
    '''
        load the trained classifier and clusters information from disk
    ''' 
    def load_classifier(self, fnm,fnm1,fnm2):
        self.clfKM = joblib.load(fnm)
        self.centroid = joblib.load(fnm1)
        self.clfDT = joblib.load(fnm2)
    
    '''
        based on fs_method parameter, create the feature_selection model, which caan then be used
        parameters can be changed if user wishes.
        'UNI' implements Univariate selection model and different modes can be used
        'SFM' implements Select From Model selection model, different classifier can be used from ensemble pack.
    '''
    def f_selection(self,x,y,fs_method):
        if fs_method=='UNI':
            self.fsm=feature_selection.GenericUnivariateSelect(score_func=feature_selection.chi2,mode='fdr',param=0.05).fit(x, y)
        elif fs_method=='SFM':
            clf1 = ensemble.ExtraTreesClassifier()
            clf1 = clf1.fit(x, y)
            self.fsm = feature_selection.SelectFromModel(clf1, prefit=True, threshold=0.25)
           
           
    '''
        This function uses training data to compute the cluster centers and also the appropriate 
        label for the cluster according to the problem and stores it in the dictionary "centroid"
        centroid['center'] stores cluster center
        centroid['label'] stores the label of cluster
    '''
    def define_clusters(self):
        self.centroid = {}
        self.normal_cent=0
        Dict = {}
        (row,col) = self.XT['data'].shape
        for i in range(0,row):
            try:
                Y = Dict[self.YTpre[i]]['y']
                Y = np.append(Y, self.YT['data'][i])
                X = Dict[self.YTpre[i]]['x']
                X = np.vstack(( X, self.XT['data'][i] ))
                Dict[self.YTpre[i]]['y']=Y
                Dict[self.YTpre[i]]['x']=X
            except:
                tmp={}
                a = np.array([self.XT['data'][i]])
                b = np.array([self.YT['data'][i]])
                tmp['x']=a
                tmp['y']=b
                Dict[self.YTpre[i]] = tmp
                
        for i in range(0,self.n_cluster):
            tmp = {}
            a = Dict[i]['x']
            a = np.mean(a, axis=0)
            tmp['center']=a
            b = Dict[i]['y']
            (x,) = b.shape
            count = {}
            for j in range(0,x):
                try:
                    count[b[j]]+=1
                except:
                    count[b[j]]=1
            lb=0
            ct=0
            for key in count.keys():
                if count[key]>ct:
                    ct = count[key]
                    lb=key
            tmp['label']=lb
            self.centroid[i]=tmp
            if self.centroid[i]['label']==1:
                self.normal_cent+=1
     


    '''
        calculate euclidean distance between two vectors
    '''
    def calc_eucd(self,a,b):
        return np.linalg.norm(a-b)
   
   
    
    '''
        This function train the classifier on the training data
        Parameters: control parameters of algorithm and is data to be normalised
    '''
    def trainData(self,is_feature_selection=False, is_norm=False, para_n_cluster=34, para_n_init=14, para_max_iter=600, para_n_jobs=2, para_max_depth=12, para_min_samples_leaf=40, para_min_samples_split=2, fs_method='UNI'):
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][0],'rb')
        self.XT = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.trainfold_indx] + '/' + self.file_names[self.trainfile_indx][1],'rb')
        self.YT = pickle.load(fr)
        fr.close()
        if is_norm==True:
            self.XT['data'] = normalize(self.XT['data'], axis=0)
            
        if is_feature_selection==True:
            self.f_selection(self.XT['data'], self.YT['data'], fs_method)
            self.XT['data']=self.fsm.transform(self.XT['data'])
        
        '''
            training Decision tree classifier
        '''
        self.clfDT = DecisionTreeClassifier(max_depth=para_max_depth, min_samples_leaf=para_min_samples_leaf,
                                          min_samples_split=para_min_samples_split)
        self.clfDT = self.clfDT.fit(self.XT['data'], self.YT['data'])
        
        '''
            training k-means clustering and labeling clusters
        '''
        self.n_cluster=para_n_cluster
        self.clfKM = KMeans(n_clusters=para_n_cluster, init='k-means++', n_init=para_n_init, max_iter=para_max_iter,
                          tol=0.001, precompute_distances='auto', verbose=0, random_state=None, copy_x=True,
                          n_jobs=para_n_jobs)
                          
        self.clfKM = self.clfKM.fit(self.XT['data'])
        self.YTpre = self.clfKM.predict(self.XT['data'])
        self.define_clusters()
    
    
    
    def modify_five(self,X,Y):
        nor=0
        (r,) = Y.shape
        for i in range(0,r):
            if Y[i]==0:
                nor+=1
        ana = 0.1*nor
        ana_c=0
        del_list = []
        for i in range(0,r):
            if Y[i]!=0:
                ana_c+=1
                if ana_c>ana:
                    del_list.append(i)
        X = np.delete(X, del_list, axis=0)
        Y = np.delete(Y, del_list, axis=0)
        return X,Y
    
    def modify(self,X,Y):
        nor=0
        (r,) = Y.shape
        for i in range(0,r):
            if Y[i]==1:
                nor+=1
        ana = 0.01*nor
        ana_c=0
        del_list = []
        for i in range(0,r):
            if Y[i]==-1:
                ana_c+=1
                if ana_c>ana:
                    del_list.append(i)
        X = np.delete(X, del_list, axis=0)
        Y = np.delete(Y, del_list, axis=0)
        return X,Y
    
    
    '''
        This function predict the classes using the classifier on the training data
        Parameters: control parameters of algorithm and is data to be normalised
    '''
    def predictData(self,is_feature_selection=False, is_norm=False):
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][2],'rb')
        Xt = pickle.load(fr)
        fr.close()
        fr = open('' + self.folder[self.testfold_indx] + '/' + self.file_names[self.testfile_indx][3],'rb')
        self.Yt = pickle.load(fr)
        fr.close()
        self.Yt = self.Yt['data']
        (self.r, ) = self.Yt.shape
        if is_norm==True:
            Xt['data'] = normalize(Xt['data'], axis=0)
            
        if is_feature_selection==True:
            Xt['data']=self.fsm.transform(Xt['data'])
            
        #modify test data
#        Xt['data'], self.Yt = self.modify_five(Xt['data'],self.Yt)
        (self.r, ) = self.Yt.shape
        self.Ypre = self.clfKM.predict(Xt['data'])
        for i in range(0,self.r):
            if self.Ypre[i]!=1:
                pre = self.clfDT.predict(Xt['data'][i].reshape(1,-1))
                self.Ypre[i] = pre[0]
    
    
    
    '''
        This function evaluate the performance of the classifier on the test data,
        in terms of percentage correct prediction.
    '''
    def evaluate(self):
        match = 0
        t_n=0
        t_a=0
        n_n=0
        a_a=0
        n_a=0
        a_n=0
        for i in range(0,self.r):
            if self.Yt[i]==self.Ypre[i]:
                match+=1
            if self.Yt[i]!=0:
                t_a+=1
                if self.Ypre[i]!=0:
                    a_a+=1
                else:
                    a_n+=1
            if self.Yt[i]==0:
                t_n+=1
                if self.Ypre[i]==0:
                    n_n+=1
                else:
                    n_a+=1
        pr = float(a_a)/(a_a + n_a)
        re = float(a_a)/(a_a + a_n)
        print "total requests: " + str(t_n + t_a)
        print "total normal: " + str(t_n) + " correct np: " + str(n_n) + " incorrect np: " + str(n_a)
        print "total abnormal: " + str(t_a) + " correct ap: " + str(a_a) + " incorrect ap: " + str(a_n)
        print "percenrage accuracy: " + str(float(match*100)/self.r)
        print "precision: " + str(pr)
        print "recall: " + str(re)
        print "F1: " + str(float(2*pr*re)/(pr+re))
# -*- coding: utf-8 -*-
"""
Created on Sat Mar 26 21:56:24 2016

@author: Sukhpal
"""

import csv
import numpy as np
import pickle

class preprocess:
    filenm = ""
    data = {}
    F_2 = {}
    F_3 = {}
    F_4 = {}
    F_y = {}
    
    attack_type = {'normal':0,'ipsweep':4,'nmap':4,'portsweep':4,'satan':4,'phf':3,'spy':3,
    'warezclient':3,'warezmaster':3,'multihop':3,'ftp_write':3,'guess_passwd':3,'imap':3,'back':1,
    'land':1,'neptune':1,'pod':1,'smurf':1,'teardrop':1,'rootkit':2,'perl':2,'loadmodule':2,'buffer_overflow':2}
    
    feilds = ['id','duration','protocol_type','service','flag','src_bytes','dst_bytes','land',
    'wrong_fragment','urgent','hot','num_failed_logins','logged_in','num_compromised','root_shell','su_attempted',
    'num_root','num_file_creations','num_shells','num_access_files','num_outbound_cmds','is_host_login',
    'is_guest_login','count','srv_count','serror_rate','srv_serror_rate','rerror_rate','srv_rerror_rate',
    'same_srv_rate','diff_srv_rate','srv_diff_host_rate','dst_host_count','dst_host_srv_count',
    'dst_host_same_srv_rate','dst_host_diff_srv_rate','dst_host_same_src_port_rate','dst_host_srv_diff_host_rate',
    'dst_host_serror_rate','dst_host_srv_serror_rate','dst_host_rerror_rate','dst_host_srv_rerror_rate','class']
    
    def __init__(self, fnm):
        self.filenm = fnm
    
    def create_maps(self):
        f2=0
        f3=0
        f4=0
        fy=1
        for key in self.data.keys():
            t = self.data[key]
            try:
                self.F_2[t[1]]['count']+=1
            except:
                tmp = {}
                tmp['code']=f2
                tmp['count']=1
                self.F_2[t[1]]=tmp
                f2+=1
            try:
                self.F_3[t[2]]['count']+=1
            except:
                tmp = {}
                tmp['code']=f3
                tmp['count']=1
                self.F_3[t[2]]=tmp
                f3+=1
            try:
                self.F_4[t[3]]['count']+=1
            except:
                tmp = {}
                tmp['code']=f4
                tmp['count']=1
                self.F_4[t[3]]=tmp
                f4+=1
            try:
                self.F_y[t[-1]]['count']+=1
            except:
                tmp = {}
                if t[-1]=='normal':
                    tmp['code']=0
                else:
                    tmp['code']=fy
                    fy+=1
                tmp['count']=1
                self.F_y[t[-1]]=tmp
        print self.F_y
                
    
    def read_csv(self):
        fr = open(self.filenm, 'rb')
        csvreader = csv.DictReader(fr)
        for row in csvreader:
            l = []
            for i in range(1,43):
                l.append(row[self.feilds[i]])
            self.data[row['id']] = l
        print len(self.data)
    
    def create_database_binary(self,XTfile,YTfile,Xtfile,Ytfile):
        k=1
        XT = []
        YT = []
        Xt = []
        Yt = []
        for key in self.data.keys():
            t = self.data[key]
            tnew = []
            for i in range(0,42):
                if i==1:
                    tnew.append(float(self.F_2[t[i]]['code']))
                elif i==2:
                    tnew.append(float(self.F_3[t[i]]['code']))
                elif i==3:
                    tnew.append(float(self.F_4[t[i]]['code']))
                elif i==41:
                    if self.F_y[t[i]]['code']==0:
                        tnew.append(1)
                    else:
                        tnew.append(-1)
                else:
                    tnew.append(float(t[i]))
            if k<=80000:
                XT.append(tnew[:len(tnew)-1])
                YT.append(tnew[-1])
            else:
                Xt.append(tnew[:len(tnew)-1])
                Yt.append(tnew[-1])
            k+=1
            
        X_train = {'data':np.array(XT)}
        Y_train = {'data':np.array(YT)}
        X_test = {'data':np.array(Xt)}
        Y_test = {'data':np.array(Yt)}
        fw = open(XTfile, 'wb')
        pickle.dump(X_train, fw)
        fw.close()
        fw = open(YTfile, 'wb')
        pickle.dump(Y_train, fw)
        fw.close()
        fw = open(Xtfile, 'wb')
        pickle.dump(X_test, fw)
        fw.close()
        fw = open(Ytfile, 'wb')
        pickle.dump(Y_test, fw)
        fw.close()
    
    def count_binary(self):
        k=1
        Tr = {'normal':0, 'attack':0}
        Te = {'normal':0, 'attack':0}
        for key in self.data.keys():
            t = self.data[key]
            if k<=80000:
                if t[-1]=='normal':
                    Tr[t[-1]]+=1
                else:
                    Tr['attack']+=1
            else:
                if t[-1]=='normal':
                    Te[t[-1]]+=1
                else:
                    Te['attack']+=1
            k+=1
        print Tr
        print Te
    
    def create_database_five(self,XTfile,YTfile,Xtfile,Ytfile):
        k=1
        XT = []
        YT = []
        Xt = []
        Yt = []
        for key in self.data.keys():
            t = self.data[key]
            tnew = []
            for i in range(0,42):
                if i==1:
                    tnew.append(float(self.F_2[t[i]]['code']))
                elif i==2:
                    tnew.append(float(self.F_3[t[i]]['code']))
                elif i==3:
                    tnew.append(float(self.F_4[t[i]]['code']))
                elif i==41:
                    try:
                        tnew.append(self.attack_type[t[i]])
                    except:
                        tnew.append(-1)
                else:
                    tnew.append(float(t[i]))
            if k<=80000:
                XT.append(tnew[:len(tnew)-1])
                YT.append(tnew[-1])
            else:
                Xt.append(tnew[:len(tnew)-1])
                Yt.append(tnew[-1])
            k+=1
            
        X_train = {'data':np.array(XT)}
        Y_train = {'data':np.array(YT)}
        X_test = {'data':np.array(Xt)}
        Y_test = {'data':np.array(Yt)}
        fw = open(XTfile, 'wb')
        pickle.dump(X_train, fw)
        fw.close()
        fw = open(YTfile, 'wb')
        pickle.dump(Y_train, fw)
        fw.close()
        fw = open(Xtfile, 'wb')
        pickle.dump(X_test, fw)
        fw.close()
        fw = open(Ytfile, 'wb')
        pickle.dump(Y_test, fw)
        fw.close()
            
if __name__=='__main__':
    x = preprocess('datafile.csv')
    x.read_csv()
    x.create_maps()
    x.create_database_binary('TrainX_binary_full.pkl','TrainY_binary_full.pkl','TestX_binary_full.pkl','TestY_binary_full.pkl')
    x.create_database_five('TrainX_five_full.pkl','TrainY_five_full.pkl','TestX_five_full.pkl','TestY_five_full.pkl')
    x.count_binary()